function login() {

    let email = document.getElementById("email").value;
    let senha = document.getElementById("senha").value;
    let erro = document.getElementById("erro");

    erro.textContent = ""

    if (email === "" || senha === "") {
        erro.textContent = "Preencha todos os campos";
        return;
    }

    if (!email.includes("@") || !email.includes(".")) {
        erro.textContent = "Email inválido";
        return;
    }

    if (senha.length < 6) {
        erro.textContent = "Senha menos de 6 dig. (faça uma senha mais forte)";
        return;
    }


    sessionStorage.setItem("email", email);

    window.location = "pagina-logada.html";
}


if (window.location.pathname.includes("pagina-logada.html")) {

    let email = sessionStorage.getItem("email");

    if (!email) {
        window.location = "index.html";
    }

    document.getElementById("emailUser").textContent = "Logado como: " + email;

    let tema = document.cookie.replace("tema=", "");
    if (tema) {
        document.body.className = tema;
    }
}


function temaClaro() {
    document.body.className = "theme-light";
    document.cookie = "tema=theme-light";
}

function temaEscuro() {
    document.body.className = "theme-dark";
    document.cookie = "tema=theme-dark";
}

function logout() {
    sessionStorage.clear();
    document.cookie = "tema=; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
    window.location = "index.html";
}
